

// implements a graph using an adjacency matrix 
//
// does breadth-first graph traversal printing out the visited nodes
// breadth-first is iterative and uses a queue as a temporary buffer 
// for nodes still to process


using System;


// defines the graph; ugly enough to do it inside the class definition .... 

class Graph {
	public int n=6;   // number of nodes 
	public int[,] g = { {0, 1, 0, 1, 0, 0},
						{0, 0, 0, 0, 0, 1},
						{0, 0, 0, 0, 0, 0},
						{0, 0, 1, 0, 1, 0},
						{1, 0, 0, 0, 0, 1},
						{0, 0, 1, 0, 0, 0}
						};  // adjacency matrix 
}


// A Queue of nodes required for breadth first 
// Note: The queue slots and methods one would usually encapsulate inside the class
// and make accessible via methods only 
class Queue {
	public Node firstNode ;
	public Node lastNode ;
}
// single nodes of integer data for simplicity (the node numbers)  
class Node {
	public int data ;
	public Node next ;
}



class Program { 

	// the Queue implementation 
	// just insert (at end), remove (at front) and isEmpty is enough

	static void queueAdd( Queue q, int i ) 
	{
		Node newNode = new Node();
		newNode.data = i;
		if ( queueIsEmpty( q ) )
			q.firstNode = q.lastNode = newNode ;
		else {
			q.lastNode.next = newNode ; 
			q.lastNode = newNode ;
		}
	}

	static int queueRemove(Queue q) {
		
		if ( queueIsEmpty( q ) ) {
			System.Console.WriteLine( "ERROR" );
			return( -1 );
		} else {
			int temp      = q.firstNode.data;
			q.firstNode   = q.firstNode.next;
			if (queueIsEmpty(q))  q.lastNode = null;
			return ( temp );
		}
	}
	
	static Boolean queueIsEmpty( Queue q ) {
		if ( q.firstNode == null ) return true ;
		else return false ;
	}
		
	


	// now the graph algorithms 
	
	// put here whatever you want to do with a visited graph goes here
	static void visitGraphNode( int i ){
		Console.WriteLine ( i );
	}
		 
	// the breadth-first algorithm
	static void breadthFirstTraversal( Graph g, int v0 ) // non-recursive; v0 is the start node
	{
		int[] d = new int[ g.n ];
		Queue q = new Queue(); // auxiliary list of nodes encountered and still to be processed.
								// [in depth-first-search we would just enter and process them.

		for( int v=0; v<g.n; v++)  d[v] = -1;  // mark all nodes as not visited
		
		d[ v0 ] = 0;  // start with visiting the start node which has distance 0 from iself
		queueAdd( q, v0 );     // still have to visit the start node
		while( queueIsEmpty( q ) == false )  // any nodes left to process, ie visit?
		{
			int u = queueRemove( q );        // yes! take the first one ..
			
			// do in visitGraphNode whatever you want to do with the node
			visitGraphNode( u );
			
			// visit the neighbours of u
			for ( int y = 0; y < g.n; y++ )	// for all nodes / possible neighbours 
				if (   g.g[ u, y ] == 1     // if u points to y  ('points to' means 'is neighbour' or 'can reach')
			     &&  d[y] == -1 )			// and y has not yet been visited 
				{
					d[y] = d[u] + 1;		// y is 1 step further away from v0 than u; so, add 1
					queueAdd( q , y );		// children of y will have to be checked later; 
											// push them to the queue
				}
  		}
	} 
		
	static void Main() {
		
		Graph g    = new Graph();
		int n      = g.n; 		
		
		// print the adjacency matrix of the graph
		for (int i=0; i<n; i++) 
			for (int j=0; j<n; j++)
				Console.Write( g.g[i,j] );
			Console.WriteLine();

		// Breadth first traversal
		breadthFirstTraversal( g, 0 );
	}

}
