
using System;
 
	public class Program
	{	

		static bool binary_search ( int searchValue, int N, int[] array )
		{
			int bottom  = 0;  // contains always the lowest possible array element 
			int top     = N;  // always one larger than the highest possible index 
			bool isFound = false;
		
			while ( (bottom < top) & ( ! isFound ) ) // main loop 
			{
				int mid = (bottom+top)/2;
				if ( searchValue == array[mid] )       // break out of loop 
					isFound = true ;  
				else if ( searchValue < array[mid] )   // continue in lower half
					top = mid;
				else                                   // continue in upper half 
					bottom = mid+1 ;  // just mid would also work
			}
			return ( isFound );
		} 


		public static void Main()
 		{
			int N, Ntest=1000;
			Random r = new Random();
			int [] a = new int[1000000];
			int [] x = new int[Ntest]; // Array for test values
			
		
			for (int j=0; j<7; j++) 
			// do a number of runs with increasing system size
			{
				// compute 10 ^ j 
				N = (int) Math.Pow( 10, j );
			
				// create an array with random numbers IN ORDER (this should not be benchmarked)
				a[0] = r.Next(10);
				for (int i=1; i<N; i++)
					a[i] = a[i-1] + r.Next(10);
				// create an array with random numbers to test for (this should not be benchmarked)
				for (int i=0; i<Ntest; i++)
					x[i] = r.Next( a[N-1] );
			
				// get the current system time
				DateTime startTime = DateTime.Now;
				
				// start the code to benchmark
			    for (int k=0; k<Ntest; k++)
					binary_search ( x[k], N, a );
			
				// get the time again and compute the elapsed time
				TimeSpan elapsed = DateTime.Now - startTime;

				// print the elapsed time, system size, etc
				Console.WriteLine( "j = " + j + "  N = " + N + "\t time = " + elapsed.TotalMilliseconds/Ntest + " ms");
			}
		}
}
