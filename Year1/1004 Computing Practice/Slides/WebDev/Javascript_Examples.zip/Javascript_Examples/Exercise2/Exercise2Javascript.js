
function MakeTextSmaller()
{
	
}


function ReplaceText()
{
	
}



function TurnLightOn()
{
	
}

function TurnLightOff()
{
	
}
