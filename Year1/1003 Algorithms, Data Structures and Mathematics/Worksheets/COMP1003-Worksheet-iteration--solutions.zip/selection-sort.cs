

using System;


// selection sort 
//
// sort an array 
//
// puzzles are often sorted this way 
//   take the first piece, put it in place
//   take the second, put it in place 
//   and so on ...
// here, the only "place" is always the top of the 
// already sorted array part

//    array [ sorted |  unsorted ] 
//                   ^
//                   i

class Program {
	
	// find the minimum in an integer array and return its index 
	
	static int min( int n, int[] array ) {
		
		int i, j=0, min;
		
		min=array[0];
		for (i=1; i<n; i++)
		{
			if (array[i] < min )
			{
				j=i;
				min = array[i];
			}
		}
		return j;
	}
	
	// find the minimum in an integer array and return its index 
	// but starting from index  "start" (inclusive) 

	static int mins( int n, int start, int[] array ) {
		
		int i, j, min;
		
		j = start;
		min=array[start];
		for (i=start+1; i<n; i++)
		{
			if (array[i] < min )
			{
				j=i;
				min = array[i];
			}
		}
		return j;
	}
		
	static void swap ( int i, int j, int[] array )
	{
		int temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}
		
		
	static void selection_sort ( int N, int[] array )
	{
		int i, j;
			
		// for all elements to be sorted
		for ( i=0; i<N; i++)      
		{ 
			// search foward for the next largest element
			j = mins ( N, i, array );
			
			// swap the element found to upper end of the sorted array 
			swap( i, j, array );
		}		
	}
	
		
	static void Main () 
	{
		int[] array =  { 2, 13, 18, 4, 7, 9, 11, 12, 10, 1 };
		int j;
		
		// test min
		System.Console.WriteLine( min( 10 , array ) );
		// test mins
		System.Console.WriteLine( mins( 9, 5, array ) );

		// test swap 
		swap( 1, 2, array );
		swap( 8, 9, array );

		for (j=0; j<10; j++)
			System.Console.Write( array[j]  + " ");
		    System.Console.WriteLine();

		// test selection sort
	 	selection_sort( 10 , array );
		
		for (j=0; j<10; j++)
			System.Console.Write( array[j]  + " ");
		System.Console.WriteLine();
	
	}
 
}
