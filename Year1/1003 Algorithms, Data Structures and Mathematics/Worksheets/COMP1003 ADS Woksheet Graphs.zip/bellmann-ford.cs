

// This code implements the Bellman Ford algorithm, which finds the shortest path 
// from a given start node in a weighted graph to all other nodes.



using System;


// define the graph; 

class Graph {
	public int n=6;   // number of nodes 
	public int[,] g = { {0, 2, 0, 1, 0, 0},
						{0, 0, 0, 0, 0, 4},
						{0, 0, 0, 0, 0, 0},
						{0, 0, 5, 0, 2, 0},
						{1, 0, 0, 0, 0, 1},
						{0, 0, 1, 0, 0, 0}
						};  // weight / distance matrix 
}


class Program { 

	static int[] bellman_ford( Graph g, int s )  // s is the start node 
	{
		int n = g.n;
		int [] d = new int [ n ];

		// Set up an array d with d[x] set to infinity (ie a very large number)
		for (int i = 0; i < n; i++)
			d[i] = 1000000;
		d[s] = 0;

		// Execute the following code n-1 times (n is the number of vertices):
		for (int i = 0 ; i < n-1 ; i++)
		{
			// For all pairs of nodes ..
			for (int a = 0 ; a < n ; a++) 
				for (int b = 0 ; b < n ; b++)
					if ( g.g[a, b] > 0 )     //  .. if there is an edge from a to b ..
						
          				if ( d[b] > d[a] + g.g[a, b]) // .. if b is currently more distant from s than a plus the edge
           					 d[b] = d[a] + g.g[a, b] ;   // we have found a shorter path
		}

		return d;
	}
	
	
	static void Main() {
		
		Graph g    = new Graph();
		int n      = g.n; 
		int [] d;
				
		// print the adjacency matrix of the graph
		for (int i=0; i<n; i++) 
		{
			for (int j=0; j<n; j++)
			{
				Console.Write( g.g[i,j] );
			}
			Console.WriteLine();
		}

		// run the algorithm
		d = bellman_ford( g, 0 );
		
		
		// print the results 
		for (int i=0; i<n; i++) 
			Console.WriteLine( i + " : " + d[i] );
	}

}

