
using System;
 
	public class Program
    {	
		// this is the function to benchmark // replace with yor own ...
		static public void Sum( int n )	
		{
			int result = 0;
			for ( int i = 0; i < n; i++ )
				result += i;
		}

		public static void Main()
 		{
		    int N;
		
			for (int j=0; j<7; j++) 
			// do a number of runs with increasing system size
			{
				// compute 10 ^ ( j+3 )  // other code may need smaller numbers ie 0, 1, or 2 instead of 3?
				N = (int) Math.Pow( 10, j+3 );
			
				// get the current system time
				DateTime startTime = DateTime.Now;
				
				// start the code to benchmark // your code would go here ..
				Sum ( N );
		
				// get the time again and compute the elapsed time
				TimeSpan elapsed = DateTime.Now - startTime;

				// print the elapsed time, system size, etc
				Console.WriteLine( "j = " + j + "  N = " + N 
									 + "\t time = " + elapsed.TotalMilliseconds );
			}
		}
}
