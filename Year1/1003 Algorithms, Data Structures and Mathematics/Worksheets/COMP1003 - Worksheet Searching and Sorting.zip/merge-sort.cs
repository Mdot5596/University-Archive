
 using System;
 
 public class MergeSort 
{
 	// 'data' is the full array 
	// 'left' and 'right' are the left and right 
	// indexes of the subarrays to sort 
	// call at top-level with Sort( array, 0, N-1 )
	// for an array of length N
	
	public static void Sort (int[] data, int left, int right)
	{
		// your code goes here 
	}


	// comment me !! understand me !!
	public static void Merge(int[] data, int left, int middle, int middle1, int right) 
	{
		int oldPosition = left;         
		int size = right - left + 1;
		int[] temp = new int[size];  
 		int i = 0;  
     
		while (left <= middle && middle1 <= right) {

			if (data[left] <= data[middle1]) 
				temp[i++] = data[left++];
			else
				temp[i++] = data[middle1++];
		}

		if (left > middle) 
			for (int j = middle1; j <= right; j++)
				temp[i++] = data[middle1++];
		else
			for (int j = left; j <= middle; j++)
				temp[i++] = data[left++];

		for (i=0; i<size; i++)
			data[oldPosition+i] = temp[i];
	}
   
	
	// some testing 
	public static void Main (String[] args)
	{
		int[] data = new int[]{2,3,1,6,2,98,4,6,4,3,45};
     
		for (int i = 0; i < data.Length; i++)
			Console.Write(data[i] + " ");
		Console.WriteLine();

	
		Sort(data, 0, data.Length-1);
 
		
		for (int i = 0; i < data.Length; i++)
			Console.Write(data[i] + " ");

		Console.WriteLine();
 	}
}
