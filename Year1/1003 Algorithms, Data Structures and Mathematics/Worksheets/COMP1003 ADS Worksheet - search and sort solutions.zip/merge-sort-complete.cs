
 using System;
 
 public class MergeSort 
{
 	// 'data' is the full array 
	// 'left' and 'right' are the left and right 
	// indexes of the subarray to sort 
	// call at top-level with Sort( array, 0, N-1 )
	// for and array of length N
	
	public static void Sort (int[] data, int left, int right)
	{	
		if (left < right) // if not .. nothing to sort
		{ 
			int middle = (left + right)/2;  // split in halves

			// sort sub arrays independently ...
			Sort(data, left, middle);       
			Sort(data, middle + 1, right);

			// after sorting merge the subarrays 
			Merge(data, left, middle, middle+1, right);
		}
	}


	// this function merges the elements of two subarrays of the array 'data'
	// the first subarray extends from 'left' to 'middle' (inclusive) and the second from
	// 'middle1' to 'right'. The subarrays are assumed ot be adjacent ie middle1=middle+1
	// the sorted data is returned starting at index 'left' 

	public static void Merge(int[] data, int left, int middle, int middle1, int right) 
	{
		int oldPosition = left;          // store the start position 
		int size = right - left + 1;     // potentially dangerous; assumes adjacent data arrays
		int[] temp = new int[size];      // temporary storage 
 		int i = 0;  
     
		//  sort input arrays left to right into temp array 
		while (left <= middle && middle1 <= right) {

			if (data[left] <= data[middle1]) 
				temp[i++] = data[left++];
			else
				temp[i++] = data[middle1++];
		}

		// if data is left in one of the arrays 
		// copy it to temp as it is already sorted
		// (as both input arrays come in sorted)
		if (left > middle) 
			for (int j = middle1; j <= right; j++)
				temp[i++] = data[middle1++];
		else
			for (int j = left; j <= middle; j++)
				temp[i++] = data[left++];

		// copy temp back into the data array  
		for (i=0; i<size; i++)
			data[oldPosition+i] = temp[i];
	}
   
	
	// some testing 
	public static void Main (String[] args)
	{
		int[] data = new int[]{2,3,1,6,2,98,4,6,4,3,45};
     
		for (int i = 0; i < data.Length; i++)
			Console.Write(data[i] + " ");
		Console.WriteLine();

	
		Sort(data, 0, data.Length-1);
 
		
		for (int i = 0; i < data.Length; i++)
			Console.Write(data[i] + " ");

		Console.WriteLine();
 	}
}
