
// implements a graph using an adjacency matrix 
//
// does depth-first traversal printing out the visited nodes
// depth-first is recursive;


using System;


// defines the graph; ugly enough to do it inside the class definition .... 

class Graph {
	public int n=6;   // number of nodes 
	public int[,] g = { {0, 1, 0, 1, 0, 0},
						{0, 0, 0, 0, 0, 1},
						{0, 0, 0, 0, 0, 0},
						{0, 0, 1, 0, 1, 0},
						{1, 0, 0, 0, 0, 1},
						{0, 0, 1, 0, 0, 0}
						};  // adjacency matrix 
}



class Program { 
	
	// put here whatever you want to do with a visited graph goes here
	static void visitGraphNode( int i ){
		Console.WriteLine ( i );
	}
	

	// the depthFirstTraversal-function is recursive; i is the node to expand,
	// v keeps track of which nodes have already been visited; 
	
	static void depthFirstTraversal( Graph g, int i, bool[] v )
	{
		// do in visitGraphNode whatever you want to do with the node
		// (in general the node will have some more meaningful data than a number)
		visitGraphNode(i) ; 
		
		// mark node as visited
		v[i] = true ;
		
		// traverse the neighbours of i
		for ( int y = 0; y < g.n; y++ )	// for all nodes / possible neighbours 
			if (   g.g[ i, y ] == 1     // if i is neighbour of y
			     &&  ! v[y] )			// and y has not yet been visited 
				depthFirstTraversal( g, y, v ) ; // then visit node y 
	}
		
	static void Main() {
		
		Graph g    = new Graph();
		int n      = g.n; 
		bool[] v   = new bool[ n ];
		
		
		// print the adjacency matrix of the graph
		for (int i=0; i<n; i++) 
			for (int j=0; j<n; j++)
				Console.Write( g.g[i,j] );
			Console.WriteLine();

		
		// Depth first traversal
		for (int i=0; i<n; i++) v[i] = false ; // mark all nodes as unvisited
		depthFirstTraversal( g, 0, v ) ;
		
	}

}
