function CreatePlayer()
{

}
