
using System;


class Program { 

    // the following lines define a simple random number generator
    // for numbers in the range 0 to value-1;
	
    static UInt32 __seed = 1;
	
    static int randInt( int value ) {
      __seed = (2416 * __seed + 374441)  %  1771875;  // RAND_MAX = 1771875
      return( (int) __seed % value ); 
    } 
	
    static void Main() {
		
		__seed = 12543;  // one seed 
		for (int i=0; i<10; i++)  // creates a sequence of pseudo random numbers 
			Console.Write( randInt( 100000 ) + " " );
		Console.WriteLine();
		
		__seed = 99345;  // anther seed 
		for (int i=0; i<10; i++)  // creates another sequence 
			Console.Write( randInt( 100000 ) + " " );
		Console.WriteLine();
		
		__seed = 12543;  // The previous seed 
		for (int i=0; i<10; i++)  // creates creates the first sequence again
			Console.Write( randInt( 100000 ) + " " );
		Console.WriteLine();
		
		// Note: the above random number generator is very bad! It generates a 
		// relatively short cyclic sequence only; different seeds just start at different positions
		
    }
}
