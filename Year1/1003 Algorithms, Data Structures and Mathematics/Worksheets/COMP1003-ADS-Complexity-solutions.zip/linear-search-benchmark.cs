
using System;
 
	public class Program
	{	

		static bool linear_search ( int searchValue, int N, int[] array )
		{
			for (int i=0; i<N; i++) 
				if ( searchValue == array[i] )
					return ( true );
			return false;
		} 
	

		public static void Main()
 		{
			int N, Ntest=1000;
			Random r = new Random();
			int [] a = new int[1000000];
			int [] x = new int[Ntest]; // Array for test values
			
		
			for (int j=0; j<7; j++) 
			// do a number of runs with increasing system size
			{
				// compute 10 ^ j 
				N = (int) Math.Pow( 10, j );
			
				// create an array with random numbers (this should not be benchmarked)
				for (int i=0; i<N; i++)
					a[i] = r.Next();
				// create an array with random numbers to test for (this should not be benchmarked)
				for (int i=0; i<Ntest; i++)
					x[i] = r.Next();
			
				// get the current system time
				DateTime startTime = DateTime.Now;
				
				// start the code to benchmark
			    for (int k=0; k<Ntest; k++)
					linear_search ( x[k], N, a );
			
				// get the time again and compute the elapsed time
				TimeSpan elapsed = DateTime.Now - startTime;

				// print the elapsed time, system size, etc
				Console.WriteLine( "j = " + j + "  N = " + N + "\t time = " + elapsed.TotalMilliseconds/Ntest + " ms");
			}
		}
}
