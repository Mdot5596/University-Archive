
// queue using an array of size 100 and data shifting
// (comments really should be more elaborate than this ...)


using System;


class queue {
   public int back;                      // youngest entry
   public int[] data = new int [ 100 ] ; // N would be more flexible than 100 ...
}


class Program { 

    static void add(queue q, int i) {
        if ( q.back == 99 ) {
			System.Console.WriteLine( "ERROR" ); // better error handling?
        } else {
            q.back = q.back + 1 ;
            q.data [ q.back ] = i ;
        }
    }

    static int remove(queue q) {
		
        if ( q.back < 0 ) {
			System.Console.WriteLine( "ERROR" );
			return( -1 );
        } else {
			int temp = q.data[0];
			
			// shuffle the remaining data 
			for ( int i=0; i < q.back; i=i+1 )
				q.data[i] =  q.data[i+1];
			
			q.back = q.back - 1 ;

        	return ( temp );
        }
    }

	
    static void Main() {
		
        queue q = new queue ();
        int i ;
		
        q.back = -1 ;
        for ( i = 0; i < 10; i = i+1 )
            add( q , i );
		
		Console.WriteLine( q.back );
		
        for ( i = 0; i < 10; i = i+1 )
            System.Console.WriteLine( remove( q ) );

    }
}
