var isLightOn = false;
function ToggleLight()
{
	
}


