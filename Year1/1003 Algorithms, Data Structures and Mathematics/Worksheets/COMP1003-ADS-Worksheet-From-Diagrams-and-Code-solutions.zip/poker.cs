using System;
using System.Collections.Generic;
using System.Text;

namespace Poker
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                int[] hand = new int[5];
                int i = 0;
                while (i < 5)
                {
                    Console.WriteLine((i + 1) + ": value? ");
                    hand[i] = Convert.ToInt32(Console.ReadLine());
                    if (hand[i] < 1)
                        break;
                    i++;
                }
                if (i < 5)
                    break;
                Console.WriteLine();
                Console.Write("hand is");
                for (int j = 0; j < 5; j++)
                {
                    Console.Write(" " + hand[j]);
                }
                Console.Write(": ");

                // STEP 1
                int[] count = new int[13];
                for (int j = 0; j < 5; j++)
                {
                    count[hand[j] - 1]++;
                }

                // STEP 2
                bool found4 = false, found3 = false;
                int found2 = 0;
                for (int j = 0; j < 13; j++)
                {
                    if (count[j] == 4)
                        found4 = true;
                    else if (count[j] == 3)
                        found3 = true;
                    else if (count[j] == 2)
                        found2++;
                }

                // STEP 3
                if (found4)
                    Console.WriteLine("four of a kind");
                else if (found3)
                {
                    if (found2 > 0)
                        Console.WriteLine("full house");
                    else
                        Console.WriteLine("three of a kind");
                }
                else if (found2 == 2)
                    Console.WriteLine("two pairs");
                else if (found2 == 1)
                    Console.WriteLine("a pair");
                else
                    Console.WriteLine("nothing of value");
            }
            // Console.ReadLine();
        }
    }
}

