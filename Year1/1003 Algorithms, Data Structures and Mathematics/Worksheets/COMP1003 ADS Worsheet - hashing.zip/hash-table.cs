
// this code implements a hash tabke using a fixed size array 
// the code does not deal properly with collisions; it just ignores the new data

using System;


class Hash {
	public UInt32 size     =  6 ;                  // quite a small hash table only .. 
	public UInt32 elements =  0;                   // keep track of how many slots are filled
	public String[] entry  =  new String[ 6 ] ;    // the hash table entries(or "buckets", or "slots"  
}


class Program { 
	
	// the hash function below is more laborate than the linear congruent 
	// random number generator used in the encryption/decryption example.
	// "key" is the key-string to hash; "key_len" the number of characters to use.
	// "key_len" must be shorter or equal to the total number of bytes in the key
	// (we should probably check that in inside the function for safety ...)
	
	// Note: hash functions do not have to be as complicated as this; in some 
	// applications they can be very simple, for example, if it is clear that the data 
	// will be equally distributed across the available slots.
	
	static UInt32 hash_function( String key, int key_len )
	{
		UInt32 hash = 0;
		int i;
		
		for (i = 0; i < key_len; i++) {
			hash += key[i];
			hash += (hash << 10);
			hash ^= (hash >> 6);
	    }
		hash += (hash << 3);
		hash ^= (hash >> 11);
		hash += (hash << 15);
		return hash;	
	}
	
	
	// insert a string in the hash table if it is not already there or the target slot is filled
	// Note: this function does not implement proper collision handling, but should!
	// It detects a collision, but then discards the new data.
	
	static void insert( Hash h, String s ) // this needs just O(1) time unless the hash table gets too full!
	{
		UInt32 hashValue, hashIndex;
		
		// check we still have space 
		if (h.elements >= h.size)
		{
			Console.WriteLine("The hash table is full! Insertion of " + s + " is ignored." );
			return;
		}
		
		// compute the hash value
		hashValue = hash_function( s, s.Length ); // unnecessary effort for long keys; a few bytes may suffice
		// compute the inded in the hash table
		hashIndex = hashValue % h.size ;   // "%" maps the hashValue into the size of the array
		
		// check the slot is empty 
		if ( h.entry[ hashIndex ] != null )
		{ 
			// not empty  --> check its the same or a different string
			if ( s.Equals( h.entry[ hashIndex ] ) ) 
			{
				Console.WriteLine( "The entry " + s + " exists already.");
				return; // we could also not return and update the data 
			}
			else
			{
				Console.WriteLine( "The slot for " + s + " is already filled with " + 
				           h.entry[ hashIndex ] + ". The new Data is ignored." ); // << COLLISION!
				return;
			}
		}
		
		// The slot is available; put the data there
		h.entry[ hashIndex ] = s; 
		
		h.elements++;  // book keeping
	}
	

	
	// check if a string is in the hash table
	
	static bool search( Hash h, String s ) // compare with insert()
	{
		UInt32 hashIndex = hash_function( s, s.Length ) % h.size ; 
		
		// check the slot is empty 
		if ( h.entry[ hashIndex ] != null )
		{ 
			// not empty  --> check its the same or a different string
			if ( s.Equals( h.entry[ hashIndex ] ) )  
				return true;   // ok, it's me!
			else		
				return false;  // other entry in target slot 
		}
		
		// the target slot is empty; nothing found
		return false;
	}
	
	

	// Go through the array linearly and print the data found or 'null'
	
	static void printHash( Hash h )
	{
		Console.WriteLine("\nThe content of the hash table is:");
		for (int i=0; i<h.size; i++)
		{
				if (h.entry[i] == null )
					Console.WriteLine( "null" );
				else
					Console.WriteLine( h.entry[i] );
		}
		Console.WriteLine();
	}
	
	
	
	// some tests
	static void Main()
	{
		Hash hash = new Hash();
		
		String[] stringData = { "Peter", "Tom", "Matthias", "Peter", "Tusnelda", "Mathilda", "Henry" };

		
		for (int i=0; i<3; i++)
		{
			Console.WriteLine( "Put element " + stringData[i] + " at position : " 
			                  + hash_function(  stringData[i], stringData[i].Length) % hash.size );
			insert ( hash, stringData[i] );
		}
		
		
		printHash( hash );
		
		
		
		// search for some values   // this needs O(1) time unless the hash table gets too full!!
		if ( search(hash, "Tom") )
			Console.WriteLine("Tom is in the hash");
		else
			Console.WriteLine("Tom is not in the hash table");
		
		if ( search(hash, "Bob") )
			Console.WriteLine("Bob is in the hash table");
		else
			Console.WriteLine("Bob is not in the hash table");

	}

}



