
// stack using an array of size 100
// (comments really should be more elaborate than this ...)


using System;


class stack {
   public int top ;
   public int[] data = new int [ 100 ] ;  // N would be more flexible than 100 ...
}


class Program { 

    static void push(stack q, int i) {
        if ( q.top == 99 ) {
			System.Console.WriteLine( "ERROR" ); // better error handling ?
        } else {
            q.top = q.top + 1 ;
            q.data [ q.top ] = i ;
        }
    }

    static int pop(stack q) {
		
        if ( q.top < 0 ) {
			System.Console.WriteLine( "ERROR" );
			return( -1 );
			
        } else {
			q.top = q.top - 1 ;
			return ( q.data [ q.top + 1 ] );
        }
    }

	
    static void Main() {
        stack q = new stack ();
        int i ;
		
        q.top = -1 ;
        for ( i = 0;   i < 10;   i = i + 1 ) {
            push( q , i );
        }
		
        for ( i = 0;   i < 10;   i = i + 1 ) {
            System.Console.WriteLine( pop( q ) );
        }
		
    }
}
