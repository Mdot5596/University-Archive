
using System;
 
	public class Program
    {	

		static void insertion_sort ( int N, int[] array )
		{
			int i, j, key;
		
			for ( i=0; i<N; i++)      // for all elements to be sorted
			{ 
				key = array[ i ];    // this is the next element to sort in 
				j = i-1;   // we have to search from here downward for key's place 
			    	       // in the already sorted section
			
				// search downwards for key's place
				while (  (j>=0)  &&  (array[j] > key) ) // if not found key's place
				{
					array[j+1] = array[j];            // shift right (upwards)
					j = j-1;                          // search left / downwards
				}
				array[j+1] = key;
			}		
		}
		
	
		public static void Main()
 		{
		    int N;
			Random r = new Random();
			int [] a = new int[1000000];

			for (int j=0; j<6; j++) 
			{
				N = (int) Math.Pow( 10, j );
			
				for (int i=0; i<N; i++)
					a[i] = r.Next();
			
				DateTime startTime = DateTime.Now;
				
				insertion_sort ( N, a );
		
				TimeSpan elapsed = DateTime.Now - startTime;

				Console.WriteLine( "j = " + j + "  N = " + N + "\t time = " + elapsed.TotalMilliseconds + " ms");
			}
		}
}
