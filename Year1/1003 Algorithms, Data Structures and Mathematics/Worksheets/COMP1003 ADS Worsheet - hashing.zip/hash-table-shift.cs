
// This code implements a hash table using a fixed size array.
// The code deals properly with collisions, until the array is filled.
// If a collision is detected the array is cyclically searched for the next free slot

using System;


class Hash {
	public UInt32 size     =  6 ;                  // quite a small hash only .. 
	public UInt32 elements =  0;                   // keep track of how many slots are filled
	public String[] entry  =  new String[ 6 ] ;    // the hash table entries 
}


class Program { 
	
	// the hash function below is more elaborate than the linear congruent 
	// random number generator used in the encryption/decryption example.
	// "key" is the key-string to hash; "key_len" the number of characters to use.
	// "key_len" must be shorter or equal to the total number of bytes in the key
	// (we should probably check that in inside the function for safety ...)
	
	// Note: hashing functions do not have to be as complicated as this; in some 
	// applications they can be very simple, for example, if it is clear that the date 
	// will be equally distributed across the available slots.
	
	static UInt32 hash_function( String key, int key_len )
	{
		UInt32 hash = 0;
		int i;
		
		for (i = 0; i < key_len; i++) {
			hash += key[i];
			hash += (hash << 10);
			hash ^= (hash >> 6);
	    }
		hash += (hash << 3);
		hash ^= (hash >> 11);
		hash += (hash << 15);
		return hash;	
	}
	
	
	// insert a string in the hash table unless it is full

	static void insert( Hash h, String s ) // this needs just O(1) time unless the hash gets too full!
	{
		// check we still have space 
		if (h.elements >= h.size)
		{
			Console.WriteLine("The hash table is full! Insertion of " + s + " is ignored." );
			return;
		}
		
		// compute the hash index
		UInt32 hashIndex = hash_function( s, s.Length ) % h.size ;
		
		// find a free slot by cyclically searching forward through the array until one is found.
		// We know there must be a free slot, because we checked for it 10 lines above

		bool foundSlot = false;
		while ( ! foundSlot )
		{
			if ( h.entry[ hashIndex ] == null )
			{
				foundSlot = true;
				break; // get out of the while loop
			}
			else
			{
				if ( s.Equals( h.entry[ hashIndex ] ) ) // found ourself
				{
					Console.WriteLine( "The entry " + s + " exists already.");
					return; // we should do this quietly in a real application
				}
				
				hashIndex++;    // try next slot 
				if (hashIndex >= h.size ) // wrap around cyclically
					hashIndex = 0;
			}
		}
		
		// A slot is available; put the data there
		h.entry[ hashIndex ] = s; 
		
		h.elements++; 
	}
	
	
	
	// check if a string is in the hash table
	
	static bool search( Hash h, String s )  // compare this function with insert()
	{
		UInt32 hashIndex = hash_function( s, s.Length ) % h.size ; 
		UInt32 i = hashIndex; // we need the index twice; so, don't change it; use i
		
		while ( true ) // forever;  break out of the loop using "return"
		{
			if (  h.entry[ i ] == null )
				return false;  // otherwise it would have been put here the latest 

			if ( s.Equals( h.entry[ i ] ) ) // found!
				return true; 
			else
			{
				i++;       // try the next slot 
				if ( i >= h.size ) // wrap around cyclically
					 i = 0; 
				if ( i==hashIndex ) // need this to avoid an infinite loop 
						// if the hash table is full but s is not in it
					return false;
			}
		}
	}
	


	
	// Go through the array linearly and print the data found or 'null'
	
	static void printHash( Hash h )
	{
		Console.WriteLine("\nThe content of the hash table is:");
		for (int i=0; i<h.size; i++)
		{
				if (h.entry[i] == null )
					Console.WriteLine( "null" );
				else
					Console.WriteLine( h.entry[i] );
		}
		Console.WriteLine();
	}
	
	
	// some tests
	static void Main()
	{
		Hash hash = new Hash();
		
		String[] stringData = { "Peter", "Tom", "Matthias", "Peter", 
					"Tusnelda", "Mathilda", "Henry", "Bart" };

		
		for (int i=0; i<8; i++)
		{
			Console.WriteLine( "Insert element " + stringData[i] );
			insert ( hash, stringData[i] );
		}
		
		// print the contents of the hash 
		printHash( hash );
		
		
		// search for some values   // This needs O(1) time unless the hash table is too full,
									// in which case it can approach O(N).
									// A hash table should be only filled up to about 80% in which 
									// case one has to expect roughly 3 collisions on average
									// and plenty free slots that would break the search for an 
									// element not in the hash table (see search).
		if ( search(hash, "Tom") )
			Console.WriteLine("Tom is in the hash table");
		else
			Console.WriteLine("Tom is not in the hash table");
		
		if ( search(hash, "Bart") )
			Console.WriteLine("Bart is in the hash table");
		else
			Console.WriteLine("Bart is not in the hash table");
		
	}

}



