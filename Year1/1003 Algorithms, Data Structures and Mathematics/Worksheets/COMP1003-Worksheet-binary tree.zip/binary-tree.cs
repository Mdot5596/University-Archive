
using System;


class Node 
{
	public int data ;
	public Node right ;
	public Node left ;
}


class Program 
{ 

	static void insert( ref Node tree, Node item ) 
	{

		if ( tree == null ) 
		{
			tree = item ;
			return;
		}
		
		
		if ( item.data < tree.data ) 
		{
			insert( ref tree.left , item );
		} 
		else if ( item.data > tree.data )
		{
			insert( ref tree.right , item );
		}
	}

	
	static bool searchTree( Node tree, int value ) 
	{
		if ( tree == null ) 
			return( false ) ; 
		
		if ( tree.data == value ) 
			return true;
		
		if ( value < tree.data )
			return ( searchTree( tree.left , value ) );
		else
			return ( searchTree( tree.right , value ) );
	}
		
	
	static void printTree(Node subtree) 
	{		
		if ( subtree.left != null )
			printTree( subtree.left );

		System.Console.Write( subtree.data + "  " );
		
		if ( subtree.right != null )
			printTree( subtree.right );
	}

	
	static void Main()
	{
		Node current, root = null ;
		int i ;
		Random r = new Random();
		
		for ( i = 1;   i <= 10;   i = i + 1 ) 
		{
			current = new Node ();
			current.left = null ;
			current.right = null ;
			current.data = r.Next(10) ;
			insert( ref root , current );
		}
			
		printTree( root );
		System.Console.WriteLine(); 
		
		if ( searchTree( root, 3 ) )
			System.Console.WriteLine( "3 was found");
		if ( !searchTree( root, 11 ) )
			System.Console.WriteLine( "11 was Not found");
	}
}
