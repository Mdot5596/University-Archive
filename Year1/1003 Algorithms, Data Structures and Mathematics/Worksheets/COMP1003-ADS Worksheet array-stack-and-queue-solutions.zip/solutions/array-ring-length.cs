
// queue using a cyclic array / ring buffer of size 10 

using System;


class queue {
	public int front  = -1;               // oldest entry removed here
	public int back   = -1;               // youngest entry added here
	public int length =  0;               // number of elements 
	public int[] data = new int [ 10 ] ;  // 10 elements only 
}


class Program 
{ 
	static void add(queue q, int i) 
	{
        if ( isFull(q) )
			System.Console.WriteLine( "ERROR -- value not stored" ); // error handling?
		else {  
		
			if (isEmpty(q)) 
			{
				q.front = q.back = 0; // or wherever one wants to start
				q.data[q.front] = i; 
				
			} else { // somewhat filled 
       
				if (q.back == 9) // no place left at end 
					q.back = -1; // cycle around

				q.back = q.back + 1 ;	
				q.data [ q.back ] = i ;
			}
			q.length++;
		}
	}

	static int remove(queue q) 
	{
		if ( isEmpty(q) ) 
		{
			System.Console.WriteLine( "ERROR - queue is empty" );
			return -1;
		} else {

			int temp = q.data[ q.front ];

			q.front = q.front + 1;
			if ( q.front == 10 ) 
				q.front = 0;

			q.length--;
			
			return ( temp );
		}
	}
	
	static int size(queue q)     { return ( q.length );           }

	static bool isFull(queue q)  { return( q.length >= 10 ) ;     }

	static bool isEmpty(queue q) { return ( q.length <= 0 );      }

	static int front(queue q)    { return ( q.data [ q.front ] ); }  // checks?!

	static int back(queue q)     { return ( q.data [ q.back ] );  }  // checks?!

	static void print_queue( queue q )
	{
		int i, len = size(q);
		
		if (isEmpty(q)) {
			Console.WriteLine( "Queue is empty; nothing to print"  ); 
			return;
		}
		Console.Write("queue > ");
		for( i=0; i<len; i++)
			Console.Write( q.data [ (q.front + i) % 10 ]  + "  ");  
		  // modulo operator '%' wraps back into the right array index range

		Console.WriteLine();
		Console.WriteLine( "front = " + q.front +";   back = " + q.back );

	}

	static void Main() {
	
		queue q = new queue ();
		int i ;
		
		// initialise queue and add some elements
		Console.WriteLine( "initialise queue and add some elements" );
		q.back = -1 ;
		for ( i = 1;   i < 8;   i = i + 1 ) {
			add( q , i );
			Console.WriteLine("pushed :	" + i);		
			print_queue( q );
		}
	   
		Console.WriteLine( "Queue size = "    + size(q)  ); 
		Console.WriteLine( "front element = " + front(q) ); 
		Console.WriteLine( "back element = "  + back(q)  ); 
		
		// remove some elements
		Console.WriteLine( "remove some elements" );
		for ( i = 0;   i < 5;   i = i + 1 ) 
		{
			System.Console.WriteLine( "popped : " + remove( q ) );
			print_queue( q );
		}

		Console.WriteLine( "Queue size = "    + size(q)  ); 
		
		// now add some more to see if the wrap around works
		Console.WriteLine( "now add some more to see if the wrap around works" );
		for ( i = 10;   i < 15;   i = i + 1 ) {
			add( q , i );
			Console.WriteLine("pushed :	" + i);		
			print_queue( q );
		}
		
		Console.WriteLine( "Queue size = "    + size(q)  ); 

		// now empty the queue
		Console.WriteLine( "now empty the queue" );
		int len = size(q);
		for ( i = 0;   i < len;   i = i + 1 ) 
		{
			System.Console.WriteLine( "popped : " + remove( q ) );
			print_queue( q );
		}
		
		// check we are empty 
		if (isEmpty( q ) == true)
			System.Console.WriteLine( "queue is empty" );

	}
}

