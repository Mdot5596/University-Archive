

using System;


// quick sort 
//
// sort an array using recursive sorting of smaller sub-arrays


class Program {

	// exchange elements i and j in array 
	static void swap ( int[] array, int i, int j ) {
		int temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}

	static void quick_sort( int[] array, int begin, int end ) 
	//  "begin" is the index of the smallest element in the array 
	//  "end"   is the index of the largest element in the array 
	//  call with  quick_sort( array, 0, N-1 ) on an unsorted array
	{
		int left, right;  
		int pivot, temp;  
   
		left  = begin; right = end;  
		pivot = array[(begin+end)/2];   // choose one element (can be any)


		// partition the array into elements smaller and larger than pivot   
		do { 
			// eat away already sorted elements on both sides of the 
			// still to be processed element; improves speed!
			while( ( array[left] < pivot)         && ( left  < end)   ) left++;  
			while( ( pivot       < array[right] ) && ( right > begin) ) right--;  
   
			// swap to sort; one per do-loop-cycle only; improves speed!
			if(left <= right) {  
			//	swap( array, left, right );
				temp = array[left];  
				array[left] = array[right];  
				array[right] = temp;  
				left++; right--;  
			}
  
		} while (left <= right);
   
		// do the sub arrays (if they are not empty; this stops the recursion)
		if( begin < right ) quick_sort( array, begin, right );  
		if( left  < end   ) quick_sort( array, left,  end   );  
	} 

		
		
	static void Main () 
	{
		int[] array =  { 2, 13, 18, 4, 7, 9, 11, 12, 1, 15 };
//		int[] array =  { 2, 13, 18, 4 };
		int j;
					
		quick_sort( array, 0, array.Length-1 );
		
		for (j=0; j< array.Length-1; j++)
			System.Console.Write( array[j]  + " ");
		System.Console.WriteLine();
	
	}
 
}
