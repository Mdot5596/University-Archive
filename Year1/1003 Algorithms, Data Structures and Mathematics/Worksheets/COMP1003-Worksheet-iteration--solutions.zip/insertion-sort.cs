

using System;


// insertion sort ; or "straight insertion" 
//
// sort an array using "insertion sort" 
//
// cards games are often sorted this way 
//   take the first 
//   take the second, sort it in (before or after the first)
//   take the third, sort it in (into the previous two)
//  ...

//    array [ sorted |  unsorted ] 
//                   ^
//                   i
//
//  This solution uses a single loop for the searching of the target position of the key
//  and the shuffling of the elements larger than the key to the right

class Program {
	
  static void insertion_sort ( int N, int[] array )
  {
	int i, j, key;
		
		for ( i=0; i<N; i++ )      // for all elements to be sorted
		{ 
			key = array[ i ];        // this is the next element to sort in 
			j = i-1;   // we have to search from here downward for key's place 
			           // in the already sorted section
			
			// search downwards for key's place
			while (  (j>=0)  &&  (array[j] > key) ) // if not found key's place
			{
				array[j+1] = array[j];                // shift just checked ement to the right (upwards)
				j = j-1;                              // go on searching left (downwards)
			}
			array[j+1] = key;
		}		
	}
		
		
	static void Main () 
	{
		int[] array =  { 2, 13, 18, 4, 7, 9, 11, 12, 1, 15 };
		int j;
					
		insertion_sort( 10 , array );
		
		for (j=0; j<10; j++)
			System.Console.Write( array[j]  + " ");
		System.Console.WriteLine();
	
	}
 
}
