

// this does not do the benchmarking ... left as a further erxercise .. 




using System;


// bubble sort 
//
// sort an array using "bubble sort" 


class Program {
	

  static void bubble_sort ( int N, int[] array )
  {
	int i, j, temp;
		
		for ( i=0; i<N; i++) {                  // go N times through the array  
			
			for ( j=0; j<N-1; j++) {            // at every location ...
				
				if ( array[j] > array[j+1] ) {  //  ... swap elements as required
					                               // ie, "bubble them upwards"
					temp       = array[j];
					array[j]   = array[j+1];
					array[j+1] = temp;
				}
			}
		}                                       // because the outer loop is done N times
  }                    // in the worst case an element can bubble through the whole array
	
	
	static void Main () 
	{
		int[] array =  { 2, 13, 18, 4, 7, 9, 11, 12, 1, 15 };
		int j;
					
		bubble_sort( 10 , array );
		
		for (j=0; j<10; j++)
			
			System.Console.WriteLine( array[j] );
	
	}
 
}
