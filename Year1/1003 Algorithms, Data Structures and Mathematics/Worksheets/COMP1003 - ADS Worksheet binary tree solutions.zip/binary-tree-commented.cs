
using System;


// single node in the tree; 
// usually "data" would be more complex than "int"
class Node 
{
	public int data ;
	public Node right ;
	public Node left ;
}


class Program 
{ 

	static void insert( ref Node tree, Node item ) 
	{
		// check the tree is not empty 
		if ( tree == null ) 
		{
			// if it is, make item its root node
			tree = item ;
			return;
		}
		
		
		if ( item.data < tree.data )      // item data is smaller than tree's data
		{
			// recursively insert into the left subtree
			insert( ref tree.left , item );
		} 
		else if ( item.data > tree.data ) // if item data is larger than tree's data
		{
			// recursively insert into the right subtree
			insert( ref tree.right , item );
		}
		// otherwise the data is already in the tree
	}

	
	static bool searchTree( Node tree, int value ) 
	{
		if ( tree == null ) // this breaks the recursion 
			return( false ) ; 
		
		if ( tree.data == value ) 
			return true;
		// the return value is recursively propagated 
		// back to the top level; likewise in the code below
		
		if ( value < tree.data )
			return ( searchTree( tree.left , value ) );
		else
			return ( searchTree( tree.right , value ) );
	}
		
	
	static void printTree(Node subtree) 
	{
		// recursively traverse the tree depth-first
		// printing data in in-fix order 
		
		if ( subtree.left != null )
			printTree( subtree.left );

		System.Console.Write( subtree.data + "  " );
		
		if ( subtree.right != null )
			printTree( subtree.right );
	}

	
	static void Main()  // some tests 
	{
		Node current, root = null ;
		int i ;
		Random r = new Random();
		
		// build a tree with 10 random values as data
		for ( i = 1;   i <= 10;   i = i + 1 ) 
		{
			current = new Node ();
			current.left = null ;
			current.right = null ;
			current.data = r.Next(10) ;
			insert( ref root , current );
		}
			
		// print out the (ordered!) tree
		printTree( root );
		System.Console.WriteLine(); 
		
		if ( searchTree( root, 3 ) )
			System.Console.WriteLine( "3 was found");
		if ( !searchTree( root, 11 ) )
			System.Console.WriteLine( "11 was Not found");
	}
}
