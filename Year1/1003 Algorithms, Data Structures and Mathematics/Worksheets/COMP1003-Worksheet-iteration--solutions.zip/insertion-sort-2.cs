

using System;


// insertion sort ; or "straight insertion" 
//
// sort an array using "insertion sort" 
//
// cards games are often sorted this way 
//   take the first 
//   take the second, sort it in (before or after the first)
//   take the third, sort it in (into the previous two)
//  ...

//    array [ sorted |  unsorted ] 
//                   ^
//                   i
//  This solution uses separate loops for the searching of the target position of the key
//  and the shuffling of the elements larger than the key to the right 
//

class Program {


	static void insertion_sort ( int N, int[] array )
	{	
		for ( int i=0; i<N; i++ )     
		{ 
			int j, key;
			
			key = array[ i ]; 
			
			for ( j=i-1; j>=0; j-- )
				if ( array[j] < key )
					break;
		    
			for ( int k=i; k>j+1; k-- )
				array[k] = array[k-1];  
			
			array[j+1] = key;
		}			
	}
		
		
	static void Main () 
	{
		int[] array =  { 2, 13, 18, 4, 7, 9, 11, 12, 1, 15 };
		int j;
					
		insertion_sort( 10 , array );
		
		for (j=0; j<10; j++)
			System.Console.Write( array[j]  + " ");
		System.Console.WriteLine();
	
	}
 
}
