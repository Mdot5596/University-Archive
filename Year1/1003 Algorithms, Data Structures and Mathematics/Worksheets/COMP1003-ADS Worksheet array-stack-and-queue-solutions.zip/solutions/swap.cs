

using System;

class Program {
	
	static void swap_useless ( int x, int y ) { // this swaps local copies
		int h; 
		h = x;
		x = y;
		y = h;
	}

	static void swap_useful( ref int x, ref int y ) { // this swaps originals
		int h; 
		h = x;
		x = y;
		y = h;
	}
		
	static void Main () {
		int u, v;
		
		u = 2; v = 3;
		System.Console.WriteLine( "u is " + u + "    v is " + v );
		
		swap_useless( u, v );
		System.Console.WriteLine( "u is " + u + "    v is " + v );	

		swap_useful( ref u, ref v );
		System.Console.WriteLine( "u is " + u + "    v is " + v );	
	}
}
