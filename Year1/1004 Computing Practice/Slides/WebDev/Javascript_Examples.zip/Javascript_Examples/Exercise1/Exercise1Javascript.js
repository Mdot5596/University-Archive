function AlertMessage()
{

}


function ConsoleMessage()
{

}


function WhatsMyName()
{
  
}
