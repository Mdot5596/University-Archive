


// dynamic Queue using linked data structures



using System;

// single elements in the Queue
class Node {
	public int data ;
	public Node next ;
}

// this holds the head and tail of the Queue
class Queue {
	public Node firstNode ;
	public Node lastNode ;
}


class Program { 


    static Node last( Queue q )
    {
        Node temp = q.firstNode;

        if (temp)
            while (temp.next != null)
                temp = temp.next;
        
        return temp;
    }

    static void add_d( Queue q, int i ) // this add traverses; does not use last pointer
    {
        Node newNode = new Node();
        newNode.data = i;
        newNode.next = null;

        if (isEmpty(q))
        {
            q.firstNode = newNode;
        }
        else
        {
            Node temp = last(q);
            temp.next = newNode;
        }
    }

	static void add_e( Queue q, int i )  // this add method uses last pointer
	{
		// get a new Node structure 
		Node newNode = new Node();

		// fill in the data; this would often be more than just an int
		newNode.data = i;

		// append the node to the list
		if ( isEmpty( q ) )
		{
			q.firstNode = q.lastNode = newNode ;
		}
		else
		{
			q.lastNode.next = newNode ;  // append at end
			q.lastNode = newNode ;       // register new node as last node
		}
	}

	static int remove(Queue q) {
		
		if ( isEmpty( q ) )
		{
			System.Console.WriteLine( "ERROR" );
			return( -1 );
		} 
		else 
		{
			int temp      = q.firstNode.data;
			q.firstNode   = q.firstNode.next;  // this implicitly discards the first node

			if (isEmpty(q))
				q.lastNode = null;  // not entirely necessary

			return ( temp );
		}
	}
	
	static int peek ( Queue q ) {

		if( isEmpty(q) ) {
			//  ERROR 
		}

		return ( q.firstNode.data );
	}

	static int size( Queue q ) {
		Node node;
		int size=0;
		
		for ( node=q.firstNode; node!=null; node=node.next ) size++;

		return ( size );
	}

	static Boolean isEmpty( Queue q ) {

		if ( q.firstNode == null )
			return ( true );
		else
			return ( false );
	}

		
	static void Main() {
		
		Queue q = new Queue ();
		Node  node = new Node();
		int i ;
		
		for ( i = 0; i < 10; i = i+1 )
			add( q , i );
		
		i=0;
		for ( node=q.firstNode; node!=null; node=node.next )
			Console.WriteLine( i + "  "  + node.data + " ;" ); 

		Console.WriteLine( "Queue size = " + size(q) ); 
		Console.WriteLine( "front element = " + peek(q) ); 
					    
		for ( i = 0;   i < 10;   i = i + 1 )
			System.Console.WriteLine( remove( q ) ); // this prints the data fetched from the queue
        
		if (isEmpty( q ) == true)
			System.Console.WriteLine( "Queue is empty" );
    	}
}

